var apigee = require('apigee-access');
var request = require('request');

var client_id = 'b3U66JnFpshMEeahpA7sJBXz3w';
var client_secret = 'b3U6l52pHhbd9lSYxm4y40HmbB0BjPw';


// Generate BAAS Access Token
exports.getBaasAccessToken = function (baaSParams, callback) {
	var options = {
		method: 'POST',
        uri: baaSParams.baasHost + '/' + baaSParams.baasOrg + '/' + baaSParams.baasApp + '/token',
		headers: {
		    'Content-Type': 'application/x-www-form-urlencoded'
		},
		form: {
		    'grant_type' : 'client_credentials',
		    'client_id' : client_id,
		    'client_secret' : client_secret
		}
	};

	request(options, function getBaasAccessTokenResp(error, response, data) {
	    console.log(JSON.stringify(response));
		if (error || !data || response.statusCode != 200) {
            callback({
                "status": response.statusCode,
                "fault": {
                    "faultstring": response.body.error_description,
                    "detail": {
                        "errorcode": response.body.error
                    }
                }
            });
		}

		var jsonData = JSON.parse(data);
		var accessToken = jsonData ? jsonData.access_token : undefined;
	    callback(null, accessToken, baaSParams);
	});
};