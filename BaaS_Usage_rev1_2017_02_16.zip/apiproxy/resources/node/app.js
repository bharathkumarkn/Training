var express = require('express');
var async = require('async');
var request = require('request');
var app = express();

var helper = require('./helper');

var baaSParams = {
	baasHost : 'https://apibaas-trial.apigee.net',
	baasOrg : 'aswinsegu',
	baasApp : 'sandbox'
};

app.get( '/users', function(req, res) {
    async.waterfall([
        async.apply(helper.getBaasAccessToken, baaSParams),
        function(accessToken, baaSParams, callback) {
            var options = {
                method: 'GET',
                uri: baaSParams.baasHost + '/' + baaSParams.baasOrg + '/' + baaSParams.baasApp + '/users',
                qs: {
                    'access_token': accessToken
                }
            };
            request(options, function(error, response, data) {
                if(!error) {
                    var jsonData = JSON.parse(data);
                    res.end(JSON.stringify(jsonData.entities));
                }
            });
        }
    ], function (err, data) {
        returnResponse(res, err, data, 200);
    });
});

app.get('/devices', function(req, res){
    var options = {
        method: 'GET',
        uri: baaSParams.baasHost + '/' + baaSParams.baasOrg + '/' + baaSParams.baasApp + '/devices'
    };
    request(options, function(error, response, data){
        if (!error) {
            var jsonData = JSON.parse(data);
            res.end(JSON.stringify(jsonData.entities));
        }
    });
});

app.get('/device', function(req, res){
   var uuid = req.query.uuid; 
    //var uuid = req.params('uuid'); 
    console.log('uuid: '+ uuid);
    var options = {
        method: 'GET',
        uri: baaSParams.baasHost + '/' + baaSParams.baasOrg + '/' + baaSParams.baasApp + '/devices/' + uuid,
        qs: {
            'access_token': accessToken
        }
    };
    request(options, function(error, response, data){
        if (!error) {
            var jsonData = JSON.parse(data);
            res.end(JSON.stringify(jsonData.entities));
        }
    });
});

app.post('/devices', function(req, res){
    var location = {
        "name":"testnew",
        "country":"india"
    };
    var options = {
        method: 'POST',
        uri: baaSParams.baasHost + '/' + baaSParams.baasOrg + '/' + baaSParams.baasApp + '/devices',
        json: location,
        qs: {
            'access_token': accessToken
        }
    };
    request(options, function(error, response, data){
        if (!error) {
            res.end(JSON.stringify(data));
        }
    });
});

app.listen(3000);